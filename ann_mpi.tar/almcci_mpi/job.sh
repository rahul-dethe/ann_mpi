#!/bin/bash
#SBATCH --job-name=10S_n2c48_ex
#SBATCH --nodes=2
#SBATCH --ntasks=24
#SBATCH --partition=cpu
#SBATCH --time=48:00:00
#SBATCH --output=%j.out
#SBATCH --error=%j.err
#SBATCH --exclusive

cd $SLURM_SUBMIT_DIR
source /home/koushiks/miniconda3/bin/activate
conda activate ann

mpirun -np 96 python3 exe.py 10site_pah_S.in
