#!/bin/bash
#SBATCH --job-name=ann-ci
#SBATCH --nodes=2
#SBATCH --ntasks-per-node=48
#SBATCH --exclusive
#SBATCH --partition=cpu
#SBATCH --time=94:00:00
#SBATCH --output=%j.out
#SBATCH --error=%j.err


source /scratch/d.rahul/miniconda3/bin/activate
conda activate ann-ci
cd $SLURM_SUBMIT_DIR
mpirun -np 96 python exe.py input_chain14_singlet.in


