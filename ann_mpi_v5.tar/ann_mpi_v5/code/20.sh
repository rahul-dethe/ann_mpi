#!/bin/bash

#SBATCH --job-name=20s_openmpi
#SBATCH --nodes=4
#SBATCH --ntasks-per-node=48
#SBATCH --partition=cpu
#SBATCH --time=94:00:00
#SBATCH --output=%j.out
#SBATCH --error=%j.err
#SBATCH --exclusive

ml purge
source /scratch/rahuld/2025/miniconda3/bin/activate
conda activate openmpi
cd $SLURM_SUBMIT_DIR

# Works on older OpenMPI: bind to logical CPUs (hardware threads)
mpirun -np 192 --bind-to hwthread --map-by hwthread python exe.py 20site_lc_S.in

