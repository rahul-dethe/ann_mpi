#!/bin/bash

#SBATCH --job-name=18s_12multi
#SBATCH --nodes=4
#SBATCH --ntasks-per-node=48
#SBATCH --exclusive
#SBATCH --partition=cpu
#SBATCH --time=96:00:00
#SBATCH --output=%j.out
#SBATCH --error=%j.err

source /scratch/rahuld/2025/miniconda3/bin/activate
conda activate ann_v4
cd $SLURM_SUBMIT_DIR
#mpirun -np 384 python3 exe_v3.py 18site_pah_S.in
#mpirun --bind-to core --map-by core:overload-allowed -np 384 python3 exe_v3.py 18site_pah_S.in
mpirun --bind-to core --map-by core --oversubscribe -np 192 python3 exe_v3.py 18site_pah_S.in
#mpirun --oversubscribe -np 384 python3 exe_v3.py 14site_pah_S.in

