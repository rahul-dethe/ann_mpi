How to run:
## mpirun -np x python3 exe_v3.py input.in
